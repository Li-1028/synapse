export type Detail={location:string;functionText:string;related:string[];source:string};
const heart='https://openstax.org/books/anatomy-and-physiology-2e/pages/19-1-heart-anatomy';
const kidney='https://openstax.org/books/anatomy-and-physiology-2e/pages/25-3-gross-anatomy-of-the-kidney';
const digest='https://openstax.org/books/anatomy-and-physiology-2e/pages/23-4-the-stomach';
const brain='https://openstax.org/books/anatomy-and-physiology-2e/pages/13-2-the-central-nervous-system';
const eye='https://openstax.org/books/anatomy-and-physiology-2e/pages/14-1-sensory-perception';
export const details:Record<string,Detail>={
 FJ3145:{location:'左侧腹膜后，脊柱左侧。',functionText:'过滤血液并形成尿液，参与调节体液、电解质和酸碱平衡。',related:['FJ3147'],source:kidney},
 FJ3147:{location:'右侧腹膜后，脊柱右侧。',functionText:'过滤血液并形成尿液，参与调节体液、电解质和酸碱平衡。',related:['FJ3145'],source:kidney},
 FJ2564:{location:'腹部上方，位于食管与十二指肠之间。',functionText:'暂存并搅拌食物，分泌胃液，开始蛋白质消化。',related:['FJ2563','FJ2573'],source:digest},
 FJ2428:{location:'心脏下部，此网格表示心室壁。',functionText:'心室壁的心肌收缩，推动血液离开心脏。',related:['FJ2438','FJ2439'],source:heart},
 FJ2438:{location:'心脏上部，此网格表示左心房壁。',functionText:'左心房接收来自肺静脉的血液，并将其送入左心室。',related:['FJ2428','FJ2439'],source:heart},
 FJ2439:{location:'心脏上部，此网格表示右心房壁。',functionText:'右心房接收来自体循环的静脉血，并将其送入右心室。',related:['FJ2428','FJ2438'],source:heart},
 FJ1781:{location:'颅腔后下方的小脑局部。',functionText:'小脑参与协调运动、姿势和平衡。',related:['FJ1830','FJ1775'],source:brain},
 FJ1830:{location:'颅腔后下方的小脑局部。',functionText:'小脑参与协调运动、姿势和平衡。',related:['FJ1781','FJ1775'],source:brain},
 FJ1313:{location:'左眼后方，连接视网膜与脑部。',functionText:'传递来自视网膜的视觉信息。',related:['FJ1364'],source:eye},
 FJ1364:{location:'右眼后方，连接视网膜与脑部。',functionText:'传递来自视网膜的视觉信息。',related:['FJ1313'],source:eye}
};

