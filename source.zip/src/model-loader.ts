// Content-hashed model URLs keep persistent cache entries safe across releases.
export function createModelFetcher(signal:AbortSignal){
 let active=0;
 const waiting:Array<()=>void>=[];
 const release=()=>{active--;waiting.shift()?.()};
 const cache=typeof caches==='undefined'?Promise.resolve(null):caches.open('synapse-models-meshopt-v1').catch(()=>null);
 return async (url:string,onBytes:(bytes:number)=>void)=>{
  if(active>=3)await new Promise<void>(resolve=>waiting.push(resolve));
  active++;
  try{
   signal.throwIfAborted();
   const storage=await cache;
   const saved=await storage?.match(url).catch(()=>undefined);
   if(saved){const bytes=await saved.arrayBuffer();onBytes(bytes.byteLength);return bytes}
   const response=await fetch(url,{signal});
   if(!response.ok)throw new Error(`模型下载失败 (${response.status})`);
   const copy=storage?response.clone():null;
   const chunks:Uint8Array[]=[];let length=0;
   if(response.body){const reader=response.body.getReader();while(true){const {done,value}=await reader.read();if(done)break;chunks.push(value);length+=value.byteLength;onBytes(length)}}
   else{const bytes=await response.arrayBuffer();chunks.push(new Uint8Array(bytes));length=bytes.byteLength;onBytes(length)}
   const bytes=new Uint8Array(length);let offset=0;for(const chunk of chunks){bytes.set(chunk,offset);offset+=chunk.length}
   if(copy&&storage)void storage.put(url,copy).catch(()=>{});
   return bytes.buffer;
  }finally{release()}
 };
}
