import * as THREE from 'three';
import {EffectComposer} from 'three/examples/jsm/postprocessing/EffectComposer.js';
import {RenderPass} from 'three/examples/jsm/postprocessing/RenderPass.js';
import {UnrealBloomPass} from 'three/examples/jsm/postprocessing/UnrealBloomPass.js';
import {OutputPass} from 'three/examples/jsm/postprocessing/OutputPass.js';
export function createImagingPipeline(renderer:THREE.WebGLRenderer,scene:THREE.Scene,camera:THREE.Camera,width:number,height:number){
 const composer=new EffectComposer(renderer);composer.addPass(new RenderPass(scene,camera));
 const bloom=new UnrealBloomPass(new THREE.Vector2(width,height),.34,.55,.82);composer.addPass(bloom);composer.addPass(new OutputPass());
 const uniforms={time:{value:0},enabled:{value:1}};
 const material=(color:string,vesselKind?:'artery'|'vein')=>{const m=new THREE.MeshStandardMaterial({color,roughness:.45,metalness:.15,transparent:true,side:THREE.FrontSide});const selection={value:0};m.userData.selection=selection;m.onBeforeCompile=shader=>{
  shader.uniforms.uTint={value:new THREE.Color(vesselKind==='artery'?'#fa5258':vesselKind==='vein'?'#428dff':'#a8e6ff')};
  shader.uniforms.uSelected=selection;shader.uniforms.uTime=uniforms.time;shader.uniforms.uHologram=uniforms.enabled;
  shader.vertexShader='varying vec3 vScanPosition;\n'+shader.vertexShader;
  shader.vertexShader=shader.vertexShader.replace('#include <begin_vertex>','#include <begin_vertex>\nvScanPosition=(modelMatrix*vec4(transformed,1.0)).xyz;');
  shader.fragmentShader='uniform vec3 uTint;uniform float uSelected;uniform float uTime;uniform float uHologram;varying vec3 vScanPosition;\n'+shader.fragmentShader;
  shader.fragmentShader=shader.fragmentShader.replace('#include <opaque_fragment>',`float rim=pow(1.0-abs(dot(normalize(normal),normalize(vViewPosition))),2.5);
   float scan=pow(.5+.5*sin(vScanPosition.y*500.0),20.0);
   float sweep=exp(-pow((vScanPosition.y-mod(uTime*.18,2.1))/.025,2.0));
   vec3 holo=vec3(.035,.18,.24)+vec3(.28,1.12,1.4)*rim+vec3(.08,.25,.32)*scan+vec3(.3,.8,.95)*sweep;
   holo=uTint*(.18+rim*1.7+scan*.2+sweep*.8);holo=mix(holo,uTint*1.4+rim*uTint,uSelected*.7);outgoingLight=mix(outgoingLight,holo,uHologram);\n#include <opaque_fragment>`);
 };return m;};
 return {material,render:(time:number,hologram:boolean)=>{uniforms.time.value=time;uniforms.enabled.value=hologram?1:0;bloom.strength=hologram?.4:.1;composer.render()},resize:(w:number,h:number)=>composer.setSize(w,h),dispose:()=>{composer.passes.forEach(p=>p.dispose());composer.dispose()}};
}
