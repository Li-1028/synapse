import {readFileSync,existsSync} from 'node:fs';
import {test} from 'node:test';
import assert from 'node:assert/strict';
const data=JSON.parse(readFileSync(new URL('./src/models.json',import.meta.url)));
test('each model has a unique ID, valid center and local resource',()=>{assert.equal(new Set(data.map(x=>x.id)).size,data.length);for(const x of data){assert.match(x.fma,/^FMA\d+$/);assert.equal(x.center.length,3);assert(x.center.every(Number.isFinite));assert(existsSync(new URL(`./public/models/${x.runtimeFile}`,import.meta.url)));}});
test('bone and organs are represented',()=>{for(const x of ['bone','organs'])assert(data.some(i=>i.system===x));});


test('whole skin mesh is excluded',()=>assert(!data.some(i=>i.id==='FJ2810')));

test('nerves are excluded and vessels have explicit artery or vein types',()=>{assert(!data.some(i=>i.system==='nerve'));for(const item of data.filter(i=>i.system==='vessel'))assert.equal(item.vesselKind,/vein|vena/i.test(item.en)?'vein':'artery');});

test('vascular coverage includes head, trunk, both arms and legs with artery and vein names',()=>{
 for(const name of ['Abdominal aorta','Left femoral artery','Right femoral artery','Left radial artery','Right radial artery','Left internal jugular vein','Right internal jugular vein','Left great saphenous vein','Right great saphenous vein'])assert(data.some(i=>i.system==='vessel'&&i.en===name),name);
 assert(!data.some(i=>/penis|testicular|scrot|pudendal/i.test(i.en)));
});

test('GLB files retain mesh IDs and valid binary lengths',()=>{for(const item of data){const b=readFileSync(new URL(`./public/models/${item.runtimeFile}`,import.meta.url));assert.equal(b.toString('ascii',0,4),'glTF');assert.equal(b.readUInt32LE(8),b.length);const len=b.readUInt32LE(12);const j=JSON.parse(b.toString('utf8',20,20+len));assert.equal(j.nodes[0].name,item.id);assert.equal(j.accessors[2].count,item.triangles*3);}});
